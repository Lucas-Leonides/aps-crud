const mongoose = require('moongose');

const pensamentos_intrusivosSchema = new mongoose.Schema ({
    title: {
        type: String,
        required: true
    },
    message: {
        type:String,
        required: true
    },
    createdAt:{
        type: Date,
        default: Date.now
    }
});

module.exports = moongose.model('pensamentos_intrusivos',pensamentos_intrusivosSchema);