const express = require('express');
const router = express.Router();
const pensamentos_intrusivos = require('../models/pensamentos_intrusivos');


//Criar novo pensamento
router.post('/',async(req,res) => {
    const { title, message } = req.body;
    const newpensamentos_intrusivos = new pensamentos_intrusivos ({ title,message })
    await newpensamentos_intrusivos.save();
    res.json(newpensamentos_intrusivos);

});

//listar todos os pensamentos
router.get('/',async (req,res) => {
    const pensamentos_intrusivos = await pensamentos_intrusivos.find();
    res.json(pensamentos_intrusivos);
});

//atualizar um pensamento
router.put('/:id', async (req,res) => {
    const { title,message } = req.body;
    const updatepensamentos_intrusivos =await pensamentos_intrusivos.findByIdAndUpdate(req.params.id, { title,message },{ new: true});
    res.json(updatepensamentos_intrusivos);
});

// Deletar uma pnsamento
router.delete('/:id', async (req, res) => {
    await pensamentos_intrusivos.findByIdAndDelete(req.params.id);
    res.json({ message: 'Pensamento deletado com sucesso!' });
});

module.exports = router;