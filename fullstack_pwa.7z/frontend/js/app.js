const API_URL = 'http://localhost:3000/api/pensamentos_intrusivoss';

document.getElementById('pensamentos_intrusivosForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = document.getElementById('title').value;
    const message = document.getElementById('message').value;

    const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title, message })
    });

    const pensamentos_intrusivos = await response.json();
    appendpensamentos_intrusivos(pensamentos_intrusivos);

    document.getElementById('title').value = '';
    document.getElementById('message').value = '';
});

async function loadpensamentos_intrusivos() {
    const response = await fetch(API_URL);
    const pensamentos_intrusivos = await response.json();
    pensamentos_intrusivos.forEach(appendpensamentos_intrusivos);
}

function appendpensamentos_intrusivos(pensamentos_intrusivos) {
    const li = document.createElement('li');
    li.innerHTML = `
        <strong>${pensamentos_intrusivos.title}</strong>
        <p>${pensamentos_intrusivos.message}</p>
        <button onclick="deletepensamentos_intrusivos('${pensamentos_intrusivos._id}')">Deletar</button>
    `;
    document.getElementById('pensamentos_intrusivossList').appendChild(li);
}

async function deletepensamentos_intrusivos(id) {
    await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
    document.location.reload();
}

loadpensamentos_intrusivos();
